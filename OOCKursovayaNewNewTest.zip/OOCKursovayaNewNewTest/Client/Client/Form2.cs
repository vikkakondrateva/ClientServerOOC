﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Client
{
    public partial class Form2 : Form
    {
        public Form2()
    {
        InitializeComponent();
    }
        public string FirstData { get; set; }
        public string SecondData { get; set; }

        
        private void button1_Click(object sender, EventArgs e)
        {
            if ((!string.IsNullOrEmpty(textBox1.Text)))
            {
                FirstData = textBox1.Text;
                SecondData = "1234";
                this.DialogResult = DialogResult.OK;
            }
            else
                MessageBox.Show("Введите данные", "Ошибка");
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.DialogResult != DialogResult.OK)
            {
                Application.Exit();
            }
            else
                return;
        }

    }
}
