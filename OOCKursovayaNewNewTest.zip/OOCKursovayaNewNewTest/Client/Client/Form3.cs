﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Client
{
    public partial class Form3 : Form
    {
        public string Login { get; set; }
        public string Password { get; set; }
        public string action { get; set; }
        public string FileWay { get; set; }
        public Form3()
        {
            InitializeComponent();
        }
        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if ((!string.IsNullOrEmpty(textBox1.Text)) && (!string.IsNullOrEmpty(textBox2.Text)) && (!string.IsNullOrEmpty(textBox3.Text)))
            {
                Login = textBox1.Text;
                Password = textBox2.Text;
                FileWay = textBox3.Text;
                action = "login";
                this.DialogResult = DialogResult.OK;
            }
            else
                MessageBox.Show("Введите данные", "Ошибка");
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            if ((!string.IsNullOrEmpty(textBox1.Text)) && (!string.IsNullOrEmpty(textBox2.Text)) && (!string.IsNullOrEmpty(textBox3.Text)))
            {
                Login = textBox1.Text;
                Password = textBox2.Text;
                FileWay = textBox3.Text;
                action = "register";
                this.DialogResult = DialogResult.OK;
            }
            else
                MessageBox.Show("Введите данные", "Ошибка");
        }

        private void Form3_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (this.DialogResult != DialogResult.OK)
            {
                Application.Exit();
            }
            else
                return;
        }

        private void button4_Click(object sender, EventArgs e)
        {
             textBox2.UseSystemPasswordChar = false;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = true;
        }
    }
}

