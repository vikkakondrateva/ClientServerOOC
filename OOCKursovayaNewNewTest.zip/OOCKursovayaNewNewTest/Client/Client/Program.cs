﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using System.Threading;

namespace Client
{
    static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// </summary>
        [STAThread]
        
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Form1 mainForm = new Form1();
            while (true)
            {
                if (mainForm.OpenForm1)
                {
                    Thread.Sleep(200); // чтобы ответ от сервера успел прийти и сразу не закрывалось
                    if (mainForm.RegUser)
                    {
                        Application.Run(mainForm);
                        break;
                    }
                    //else if (!mainForm.RegUser)
                    //    mainForm.PingTimer_Tick(null, EventArgs.Empty);
                }
                else if (!mainForm.OpenForm1)
                    return;
                if (mainForm.shotDown)
                    return;
            }
        }
    }
}
