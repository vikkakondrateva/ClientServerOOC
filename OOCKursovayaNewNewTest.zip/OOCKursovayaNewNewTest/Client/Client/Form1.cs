﻿using System;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading;
using System.Linq;
using System.Windows.Forms;
using System.IO;
using System.Collections.Generic;
namespace Client
{

    public partial class Form1 : Form
    {
        private TcpClient tcpClient;        //для подключения к серверу
        private Thread clientThread;        //поток для обработки сообщений с сервера
        Form3 form3;
        Form2 form2;
        public string IP = "";
        public int Port;
        public string login = null;
        public string password = null;
        public string fileWay = null;
        public string access = null;
        public string selectedLogin = "";
        string localIP = "";
        public bool typingText = false;     //начал ли пользователь набирать текст
        public bool RegUser;              //прошла ли регистрация
        public bool OpenForm1 = false; //открывать ли главную форму
        public bool formClosing = false;
        public bool receivingFile = false;  //началась ли передача файлов
        public bool shotDown = false;
        private System.Windows.Forms.Timer autoUpdateTimer; //обновление списка пользов
        private System.Windows.Forms.Timer clearTimer;      //удаление пользователя
        int UploadListInterval = 3000;
        int UploadBoxInterval = 1000;
        private List<string> currentIpList = new List<string>();    //список онлайн пользователей (по ip)
        public static object chatLogsLock = new object();           //чтобы получить доступ к объектам из другого потока
        public enum AllTypesOfCommands
        {
            Register,
            Login,
            LocalUserIP,
            UpdateUL,
            SendDirectMessage,
            SendMessageAll,
            TransferFile,
            ForTyping,
            DelUser
        }

        private void OpenForm3()
        {
            try
            {
                using (form3 = new Form3())
                {
                    if (form3.ShowDialog() == DialogResult.OK)
                    {
                        login = form3.Login;
                        password = form3.Password;
                        fileWay = form3.FileWay;
                        if (form3.action == "register")
                            RegisterUser();
                        else if (form3.action == "login")
                            LoginUser();
                    }
                    else
                    {
                        RegUser = false;
                        if (tcpClient != null && tcpClient.Connected)
                        {
                            NetworkStream clientStream = tcpClient.GetStream();
                            if (clientStream != null)
                            {
                                clientStream.Close();
                            }

                            tcpClient.Close();
                        }
                    }

                }
            }
            catch (Exception exeption)
            {
                MessageBox.Show("Ошибка открытия формы регистрации: " + exeption.Message);
            }
        }
        private void OpenForm2()
        {
            try
            {
                using (form2 = new Form2())
                {
                    if (form2.ShowDialog() == DialogResult.OK)  //если польз ввел данные
                    {
                        IP = form2.FirstData;                   //сохраняем их в переменные
                        Port = int.Parse(form2.SecondData);
                        OpenForm1 = true;
                    }
                    else
                    {
                        OpenForm1 = false;
                    }
                }
            }
            catch (Exception exeption)
            {
                MessageBox.Show("Ошибка открытия формы ip: " + exeption.Message);
            }
        }

        public class Message
        {
            public AllTypesOfCommands AllTypesOfCommands { get; set; }
            public string Sender { get; set; }
            public string Receiver { get; set; }
            public string MSG { get; set; }

            public override string ToString()   //форматирует Message в строку
            {
                return string.Format("{0}|{1}|{2}|{3}", AllTypesOfCommands, Sender, Receiver, MSG);
            }
        }

        public Form1()
        {
            OpenForm2();
            InitializeComponent();
            if (OpenForm1)     //открытие формы
            {
                try
                {
                    ConnectedToServer();                //устанавливает соединение с серверо
                    autoUpdateTimer = new System.Windows.Forms.Timer(); //обновляет список польз
                    autoUpdateTimer.Interval = UploadListInterval;
                    autoUpdateTimer.Tick += AutoUpdateTimer_Tick;
                    autoUpdateTimer.Start();

                    LocalUserIP();

                    clearTimer = new System.Windows.Forms.Timer();      //очищает список пользователей
                    clearTimer.Interval = UploadBoxInterval;
                    clearTimer.Tick += ClearOnlineUsersTimer_Tick;
                    clearTimer.Start();
                }
                catch (Exception exeption)
                {
                    MessageBox.Show("Ошибка подключения к серверу: " + exeption.Message);
                    OpenForm2();
                }
                OpenForm3();

            }
            else
            {
                Application.Exit();
            }
        }
        private void ConnectedToServer()
        {

            tcpClient = new TcpClient();
            IAsyncResult result = tcpClient.BeginConnect(IP, Port, null, null); //подкл к серверу

            bool success = result.AsyncWaitHandle.WaitOne(5000, true);      //ждет подключения

            if (!success || !tcpClient.Connected)
            {

                MessageBox.Show("Не удалось подключиться к серверу. Проверьте правильность IP и порта.");
                OpenForm2();
            }

            tcpClient.EndConnect(result);           //завершает ожидающ асинхр попытку на подключ

            clientThread = new Thread(new ThreadStart(ForServersMessages));  //запуск потока для получ соо от сервера
            clientThread.Start();
        }

        private void ClearOnlineUsersTimer_Tick(object sender, EventArgs e)    //периодич очищ список пользователей
        {
            if (listBox1.InvokeRequired)
            {
                listBox1.Invoke(new Action(() => DelNotIpInfo()));
            }
            else
            {
                DelNotIpInfo();
            }
        }
        private void DelNotIpInfo()         //очищает список пользователей от лишней информации
        {
            for (int i = 0; i < listBox1.Items.Count; i++)
            {
                string itemText = listBox1.Items[i].ToString();      //возвращает текущ эл списка и превращ его в строку
                int Space = itemText.IndexOf(' ');

                if (Space != -1)
                {
                    listBox1.Items[i] = itemText.Substring(0, Space).Trim();
                }
            }
        }
        private void AutoUpdateTimer_Tick(object sender, EventArgs e)       //запрос списка пользователей
        {

            SendMessage(AllTypesOfCommands.UpdateUL, "", "", "");

        }
        private void LoginUser()                //отпр запрос на сервер для авторизации пользователя
        {
            SendMessage(AllTypesOfCommands.Login, localIP, "", login + "," + password);
        }
        private void RegisterUser()
        {
            SendMessage(AllTypesOfCommands.Register, localIP, "", login + "," + password);
        }
        private void LocalUserIP()
        {
            SendMessage(AllTypesOfCommands.LocalUserIP, "", "", "");
        }

        private void ForServersMessages()               //tcp, коорый через бесконечный цикл прослуш сообщ с сервера
        {
            try
            {
                while (true)
                {
                    if (tcpClient != null && tcpClient.Connected)
                    {
                        NetworkStream clientStream = tcpClient.GetStream();
                        byte[] message = new byte[4096];                //создание буфера
                        int bytesRead;

                        try
                        {
                            bytesRead = clientStream.Read(message, 0, 4096);        //чтение данных из потока
                        }
                        catch
                        {
                            break;
                        }
                        if (bytesRead == 0)     //если сервер отправил 0 байтов - соединение закрыто
                            break;

                        Message receivedMessage = ByteToMessage(message, bytesRead);
                        ProcessCommand(receivedMessage);
                    }
                    else
                        return;
                }
            }
            catch (Exception exeption)
            {
                MessageBox.Show("Ошибка получения информации от сервера: " + exeption.Message);
            }
        }
        private void ProcessCommand(Message message)    //обрабатывает команды от сервера
        {
            try
            {
                typingText = false;
                string messageToRich = "";
                switch (message.AllTypesOfCommands)
                {
                    case AllTypesOfCommands.UpdateUL:
                        UpdateUserList(message.MSG);
                        break;
                    case AllTypesOfCommands.LocalUserIP:
                        localIP = message.MSG;
                        break;
                    case AllTypesOfCommands.SendDirectMessage:
                        messageToRich = "You " + message.Sender + ": " + message.MSG;
                        SaveMessageLog(message.Sender, messageToRich);
                        if (selectedLogin == message.Sender)
                            AppendTextToRichTextBoxSafe(messageToRich);
                        break;
                    case AllTypesOfCommands.ForTyping:
                        typingText = true;
                        ForTyping(message.Sender, message.MSG);
                        break;
                    case AllTypesOfCommands.SendMessageAll:
                        messageToRich = "All " + message.Sender + ": " + message.MSG;
                        SaveMessageLog(message.Sender, messageToRich);
                        if (selectedLogin == message.Sender)
                            AppendTextToRichTextBoxSafe(messageToRich);
                        break;
                    case AllTypesOfCommands.TransferFile:
                        CreateFile(message.Sender, message.MSG);
                        break;
                    case AllTypesOfCommands.Register:
                        CheckRegister(message.MSG);
                        break;
                    case AllTypesOfCommands.Login:
                        CheckLogin(message.MSG);
                        break;
                    case AllTypesOfCommands.DelUser:
                        FormClosingEventArgs e = new FormClosingEventArgs(CloseReason.UserClosing, false);
                        MessageBox.Show("Вы отключены администратором");
                        Form1Closing(this, e);
                        break;

                }
            }
            catch (Exception exeption)
            {
                MessageBox.Show("Ошибка расшифровки команды: " + exeption.Message);
            }
        }
        private static void SaveMessageLog(string sender, string message)
        {
            lock (chatLogsLock)
            {
                string logDirectory = Path.Combine(Directory.GetCurrentDirectory(), "log");
                string filePath = Path.Combine(logDirectory, sender + "_chatlog.txt");
                File.AppendAllText(filePath, message + Environment.NewLine);
            }
        }
        private void CheckLogin(string msg)     //проверка на правильность логина
        {
            string[] parts = msg.Split(',');
            string accept = parts[0].Trim();
            string rights = parts[1].Trim();
            if (accept == "False")
            {
                RegUser = false;
                MessageBox.Show("Неверный логин и/или пароль");
                OpenForm3();
            }
            else if (accept == "True")
            {
                RegUser = true;
                access = rights;
                if (access != "admin")
                    button4.Hide();
            }
        }
        private void CheckRegister(string msg)
        {
            string rights = "";
            string[] parts = msg.Split(',');
            string accept = parts[0].Trim();
            if (parts.Length > 1)
                rights = parts[1].Trim();
            if (accept == "False")
            {
                RegUser = false;
                MessageBox.Show("Такой логин/ip уже существует");
                OpenForm3();
            }
            else if (accept == "True")
            {
                RegUser = true;
                access = rights;
                if (access != "admin")
                    button4.Hide();
            }
        }
        private void ForTyping(string sender, string msg)      //отмечает пользователя, который набирает текст
        {
            try
            {
                if (listBox1.InvokeRequired)
                {
                    listBox1.Invoke(new Action(() => TypingListBoxItem(sender, msg)));
                }
                else
                {
                    TypingListBoxItem(sender, msg);
                }
            }
            catch (Exception exeption)
            {
                MessageBox.Show("Ошибка набора сообщения пользователем: " + exeption.Message);
            }
        }

        private void TypingListBoxItem(string sender, string msg)   //обновление, если печатает
        {
            
            int index = listBox1.FindString(sender);
            if (index != -1)
            {
                listBox1.Items[index] = $"{sender} {msg}"; // отображение, что пользователь печатает

                // установка таймера для сброса текста через определенное время
                var typingResetTimer = new System.Windows.Forms.Timer();
                typingResetTimer.Interval = 3000; // 3 секунды
                typingResetTimer.Tick += (s, e) =>
                {
                    if (listBox1.Items[index].ToString().Contains(msg))
                    {
                        listBox1.Items[index] = sender; // Сброс текста после завершения
                    }
                    typingResetTimer.Stop();
                    typingResetTimer.Dispose();
                };
                typingResetTimer.Start();
            }

        }
        private void AppendTextToRichTextBoxSafe(string text)      //добавление любого текста в главное поле
        {
            if (richTextBox1.InvokeRequired)
            {
                richTextBox1.Invoke(new Action(() => richTextBox1.AppendText(text + Environment.NewLine)));
            }
            else
            {
                richTextBox1.AppendText(text + Environment.NewLine);
            }
        }
        private void UpdateUserList(string userList)
        {
            if (RegUser)                        //зарегистрирован ли пользователь
            {
                try
                {
                    listBox1.Invoke(new Action(() =>
                    {
                        //разделение строки на список
                        List<string> newUserIpList = userList.Split(',').Where(loginCheck => loginCheck != "").ToList();    //с собой
                        //List<string> newUserIpList = userList.Split(',').Where(loginCheck => loginCheck != null).ToList();    //без себя

                        List<string> removedIpList = currentIpList.Except(newUserIpList).ToList();  //список IP-адресов, которые были удалены
                        foreach (string removedIp in removedIpList)                                 //удаление пользователей из ListBox1
                        {
                            listBox1.Items.Remove(removedIp);
                            currentIpList.Remove(removedIp);
                        }

                        List<string> addedIpList = newUserIpList.Except(currentIpList).ToList();    //список добавленных пользователей
                        foreach (string addedIp in addedIpList)
                        {
                            listBox1.Items.Add(addedIp);
                            currentIpList.Add(addedIp);
                        }
                    }));
                }
                catch (Exception exeption)
                {
                    MessageBox.Show("Ошибка обновления онлайна: " + exeption.Message);
                }
            }
        }

        private static Message ByteToMessage(byte[] messageBytes, int bytesRead)
        {
            string messageString = Encoding.UTF8.GetString(messageBytes, 0, bytesRead);
            string[] messageParts = messageString.Split('|');

            Message Nobyte_Message = new Message();

            if (messageParts.Length >= 4)
            {
                if (Enum.IsDefined(typeof(AllTypesOfCommands), messageParts[0]))   //точно есть 4 элемента для вывода полного сообщения
                {
                    Nobyte_Message.AllTypesOfCommands = (AllTypesOfCommands)Enum.Parse(typeof(AllTypesOfCommands), messageParts[0]);
                    Nobyte_Message.Sender = messageParts[1];
                    Nobyte_Message.Receiver = messageParts[2];
                    Nobyte_Message.MSG = messageParts[3];
                }
                else
                {
                    Console.WriteLine("Неизвестная комманда:" + messageParts[0]);
                    return null;
                }
            }
            else
            {
                Console.WriteLine("Неизвестный формат сообщения");
                return null;
            }

            return Nobyte_Message;                      //возвращаем расшифрованное сообщение
        }

        private void SendMessage(AllTypesOfCommands commandType, string sender, string receiver, string msg)   //отправляет сообщение серверу
        {
            try
            {
                NetworkStream clientStream = tcpClient.GetStream();

                byte[] messageBytes = Encoding.UTF8.GetBytes(commandType + "|" + sender + "|" + receiver + "|" + msg);
                clientStream.Write(messageBytes, 0, messageBytes.Length);       //массив байтов отправляется через поток
                clientStream.Flush();                                           //очистка буфера
            }
            catch (Exception exeption)
            {
                Console.WriteLine("Не удалось отправить сообщение: " + exeption.Message);
            }
        }
        private void button2_Click(object sender, EventArgs e)      //отправка широковещ сообщ и сохр в файл
        {
            SendMessage(AllTypesOfCommands.SendMessageAll, localIP, "", textBox1.Text);
            string messageForAll = "You for all: " + textBox1.Text;
            richTextBox1.AppendText(messageForAll + Environment.NewLine);       //отобразить в текст поле

            string logFolderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "log");  //опред путь к папке

            if (Directory.Exists(logFolderPath))            //если папка есть
            {
                string[] logFiles = Directory.GetFiles(logFolderPath);      //список всех файолв

                foreach (string logFile in logFiles)
                {
                    try
                    {
                        File.AppendAllText(logFile, messageForAll + Environment.NewLine);   //добавляет сообщ во все файлы
                    }
                    catch (Exception exeption)
                    {
                        Console.WriteLine("Ошибка при добавлении строки в файл" + exeption.Message);
                    }
                }
            }
        }
        private void button1_Click(object sender, EventArgs e)              //отправить лично
        {
            try
            {
                string selectedIndex = "";
                if (listBox1.InvokeRequired)
                {
                    listBox1.Invoke(new Action(() =>
                    {
                        if (listBox1.SelectedItem != null)
                            selectedIndex = listBox1.SelectedItem.ToString();
                    }));
                }
                else
                {
                    if (listBox1.SelectedItem != null)
                        selectedIndex = listBox1.SelectedItem.ToString();
                }

                if (!string.IsNullOrEmpty(selectedIndex) && !string.IsNullOrEmpty(textBox1.Text))   //если поля содержат текст сообщ и выбранного польз
                {
                    SendMessage(AllTypesOfCommands.SendDirectMessage, localIP, selectedIndex, textBox1.Text);
                    string messageToRich = "You: " + textBox1.Text;
                    SaveMessageLog(selectedIndex, messageToRich);           //сохр в файл
                    richTextBox1.AppendText(messageToRich + Environment.NewLine);
                }
            }
            catch (Exception exeption)
            {
                Console.WriteLine("Не удалось отправить сообщение: " + exeption.Message);
            }
        }
        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                string selectedUser = listBox1.SelectedItem.ToString();
                SendMessage(AllTypesOfCommands.ForTyping, localIP, selectedUser, "typing...");
            }
        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                string selectedUser = listBox1.SelectedItem.ToString();
                SendMessage(AllTypesOfCommands.ForTyping, localIP, selectedUser, "typing...");
            }
        }

        private void Form1Closing(object sender, FormClosingEventArgs e)   //закрывает соединение при закрытии формв
        {
            if (tcpClient != null && tcpClient.Connected)
            {
                NetworkStream clientStream = tcpClient.GetStream();
                if (clientStream != null)                   //если поток не закрыт
                {
                    clientStream.Close();
                }

                tcpClient.Close();              //освобождаем ресурсы, связанные с сетевым подключением
                Application.Exit();             //полное завершение работы
            }
        }


        private void TransferFile(string selectedIndex, string selectedFilePath)
        {
            try
            {
                using (FileStream fileStream = new FileStream(selectedFilePath, FileMode.Open, FileAccess.Read))
                {
                    string fileName = Path.GetFileName(selectedFilePath);
                    long fileSize = fileStream.Length;

                    string fileInfo = fileName + "," + fileSize;

                    int bufferSize = 512;
                    byte[] buffer = new byte[bufferSize];
                    int bytesRead;
                    while ((bytesRead = fileStream.Read(buffer, 0, bufferSize)) > 0)
                    {
                        byte[] a = buffer;
                        string hexString = BitConverter.ToString(buffer).Replace("-", " ");
                        string message = fileInfo + "," + hexString;
                        SendMessage(AllTypesOfCommands.TransferFile, localIP, selectedIndex, message);
                        Thread.Sleep(200);
                    }
                }
            }
            catch (Exception exeption)
            {
                MessageBox.Show("Ошибка при отправке файла:" + exeption.Message);
            }
        }
     
        
        private void CreateFile(string sender, string info)
        {
            try
            {
                string[] parts = info.Split(',');

                string fileName = parts[0].Trim();
                int fileSize = int.Parse(parts[1].Trim());
                string hexBytes = parts[2].Trim();

                hexBytes = RemoveNonHexCharacters(hexBytes);

                byte[] fileBytes = new byte[hexBytes.Length / 2];

                for (int i = 0; i < hexBytes.Length; i += 2)
                {
                    byte.TryParse(hexBytes.Substring(i, 2), System.Globalization.NumberStyles.HexNumber, null, out fileBytes[i / 2]);
                }

                string filePath = Path.Combine(fileWay, fileName);
                if (!receivingFile)
                {
                    string startMessage = "Начат прием файла от: " + sender + " файл: " + fileName;
                    AppendTextToRichTextBoxSafe(startMessage);

                    receivingFile = true;
                }
                using (FileStream fileStream = new FileStream(filePath, FileMode.Append, FileAccess.Write))
                {
                    fileStream.Write(fileBytes, 0, fileBytes.Length);
                }
                if (new FileInfo(filePath).Length >= fileSize && (new FileInfo(filePath).Name == fileName))
                {

                    string endMessage = "Файл получен: " + fileName + " сохранён в : " + fileWay;
                    AppendTextToRichTextBoxSafe(endMessage);

                    receivingFile = false;
                }
            }
            catch (Exception exeption)
            {
                MessageBox.Show("Ошибка при создании файла: " + exeption.Message);
                if (tcpClient != null && tcpClient.Connected)
                {
                    NetworkStream clientStream = tcpClient.GetStream();
                    if (clientStream != null)
                    {
                        clientStream.Close();
                    }

                    tcpClient.Close();
                    Application.Exit();
                }
            }
        }

        private string RemoveNonHexCharacters(string hexString)         //удаляет 16-ричные символы
        {
            return new string(hexString.Where(c => Uri.IsHexDigit(c)).ToArray());
        }

        private void button4_Click(object sender, EventArgs e)      //удалить из сети
        {
            string selectedIndex = "";
            if (listBox1.InvokeRequired)
            {
                listBox1.Invoke(new Action(() =>
                {
                    if (listBox1.SelectedItem != null)
                        selectedIndex = listBox1.SelectedItem.ToString();
                }));
            }
            else
            {
                if (listBox1.SelectedItem != null)
                    selectedIndex = listBox1.SelectedItem.ToString();
            }
            SendMessage(AllTypesOfCommands.DelUser, localIP, selectedIndex, "");
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)      //чтобы не было много файлов с одинаковыми именами
        {

            selectedLogin = listBox1.SelectedItem as string;        //значение переменной = текущий элемент списка

            if (!string.IsNullOrEmpty(selectedLogin) && !typingText)    //переменная есть и текст не набирается
            {
                string logDirectory = Path.Combine(Directory.GetCurrentDirectory(), "log");    //формирует путь к папке

                string filePath = Path.Combine(logDirectory, selectedLogin + "_chatlog.txt");    //формирует имя   

                try
                {
                    if (File.Exists(filePath))
                    {
                        string UserChat = File.ReadAllText(filePath);        //чтение файла
                        richTextBox1.Text = UserChat;
                    }
                    else
                    {
                        richTextBox1.Clear();
                    }
                }
                catch (IOException exeption)
                {
                    MessageBox.Show("Ошибка при чтении файла: " + exeption.Message);
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int maxFile = 200 * 1024 * 1024;
            FileInfo fileData = null;
            string selectedIndex = "";
            if (listBox1.InvokeRequired)
            {
                listBox1.Invoke(new Action(() =>
                {
                    if (listBox1.SelectedItem != null)
                        selectedIndex = listBox1.SelectedItem.ToString();
                }));
            }
            else
            {
                if (listBox1.SelectedItem != null)
                    selectedIndex = listBox1.SelectedItem.ToString();
            }
            if (listBox1.SelectedItem != null)
            {
                using (OpenFileDialog openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.Title = "Выберите файл";
                    openFileDialog.Filter = "Все фалы (*.*)|*.*";

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        string selectedFilePath = openFileDialog.FileName;
                        fileData = new FileInfo(selectedFilePath);
                        if (fileData.Length >= maxFile)
                        {
                            MessageBox.Show("Файл сшишком большой");
                            return;
                        }
                        else
                        {
                            MessageBox.Show("Выбран файл:" + selectedFilePath);
                            Thread fileTransferThread = new Thread(() => TransferFile(selectedIndex, selectedFilePath));
                            fileTransferThread.Start();
                        }
                    }
                }
            }
            else
                MessageBox.Show("Выберите пользователя для отправки");
        }
    }

}
