﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.IO;
public enum AllTypesOfCommands
{
    Register,
    Login,
    LocalUserIP,
    UpdateUL,
    SendDirectMessage,
    SendMessageAll,
    TransferFile,
    ForTyping,
    DelUser
}

public class Message
{
    public AllTypesOfCommands AllTypesOfCommands { get; set; }
    public string Sender { get; set; }
    public string Receiver { get; set; }
    public string MSG { get; set; }
}

class Server
{
    private static TcpListener tcpListener;                 //сервер для принятия подключений
    private static List<TcpClient> connectedClients = new List<TcpClient>();    //список подключенных клиентов
    private static object lockObject = new object();        //для синхронизации потоков при работе с общими ресурсами

    static void Main()
    {
        Console.WriteLine("The server is ready!");
        tcpListener = new TcpListener(IPAddress.Any, 1234);     //будет прослушивать входящие сообщения
        tcpListener.Start();

        Thread listenThread = new Thread(ListenClients);     //поток, выполняющий метод ListenForClients
        listenThread.Start();
    }

    private static void ListenClients()              //добавляет подключённых клиентов в список и запускает поток для их обработки.
    {
        while (true)
        {
            TcpClient tcpClient = tcpListener.AcceptTcpClient();    //принимает подключения
            connectedClients.Add(tcpClient);

            Thread clientThread = new Thread(HandleClient);
            clientThread.Start(tcpClient);
            Console.WriteLine("Client connected: " + ((IPEndPoint)tcpClient.Client.RemoteEndPoint).Address.ToString());
        }
    }

    private static void HandleClient(object obj)            //обработка взаимодействия с клиентом
    {
        TcpClient tcpClient = (TcpClient)obj;               //преобразование

        while (true)
        {
            try
            {
                NetworkStream clientStream = tcpClient.GetStream();
                byte[] Bytes = new byte[4096];
                int bytesRead = clientStream.Read(Bytes, 0, Bytes.Length);

                Message receivedMessage = BytesNotMessage(Bytes, bytesRead);

                switch (receivedMessage.AllTypesOfCommands)            //проверка типа команды
                {
                    case AllTypesOfCommands.UpdateUL:
                        UpdateAndSendUserList(tcpClient);
                        break;
                    case AllTypesOfCommands.LocalUserIP:
                        SendUserLocalIPResponse(tcpClient);
                        break;
                    case AllTypesOfCommands.SendDirectMessage:
                        SendPrivateMessage(AllTypesOfCommands.SendDirectMessage, tcpClient, receivedMessage.Sender.ToString(), receivedMessage.Receiver.ToString(), receivedMessage.MSG.ToString());
                        break;
                    case AllTypesOfCommands.ForTyping:
                        SendPrivateMessage(AllTypesOfCommands.ForTyping, tcpClient, receivedMessage.Sender.ToString(), receivedMessage.Receiver.ToString(), receivedMessage.MSG.ToString());
                        break;
                    case AllTypesOfCommands.SendMessageAll:
                        SendMessageAll(AllTypesOfCommands.SendMessageAll, tcpClient, receivedMessage.Sender.ToString(), receivedMessage.Receiver.ToString(), receivedMessage.MSG.ToString());
                        break;
                    case AllTypesOfCommands.TransferFile:
                        SendPrivateMessage(AllTypesOfCommands.TransferFile, tcpClient, receivedMessage.Sender.ToString(), receivedMessage.Receiver.ToString(), receivedMessage.MSG.ToString());
                        break;
                    case AllTypesOfCommands.Register:
                        RegisterUser(AllTypesOfCommands.Register, tcpClient, receivedMessage.Sender.ToString(), receivedMessage.MSG.ToString());
                        break;
                    case AllTypesOfCommands.Login:
                        LoginUser(AllTypesOfCommands.Login, tcpClient, receivedMessage.Sender.ToString(), receivedMessage.MSG.ToString());
                        break;
                    case AllTypesOfCommands.DelUser:
                        SendPrivateMessage(AllTypesOfCommands.DelUser, tcpClient, receivedMessage.Sender.ToString(), receivedMessage.Receiver.ToString(), receivedMessage.MSG.ToString());
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
                break;
            }
        }

        lock (lockObject)
        {
            connectedClients.RemoveAll(clientInfo => clientInfo == tcpClient);  //если елиент откл, удаление из списка
        }

    }

    //проверка входа
    private static void LoginUser(AllTypesOfCommands commandType, TcpClient sender, string senderStr, string message)
    {
        string[] partsM = message.Split(',');
        string loginM = partsM[0].Trim();
        string passwordM = partsM[1].Trim();
        bool accept = false;                    //прошла ли авторизация
        string messageToUser = "";              //результат авторизации
        try
        {
            string[] lines = File.ReadAllLines("AllUsers.txt");

            if (lines.Length > 0)
            {
                foreach (string line in lines)          //перебираем строки в файле и ищем совпадения
                {
                    string[] parts = line.Split(':');
                    if (parts.Length == 2)
                    {
                        string loginAndPassword = parts[1].Trim();
                        string[] loginPasswordArray = loginAndPassword.Split(',');

                        if (loginPasswordArray.Length == 3)
                        {
                            string login = loginPasswordArray[0].Trim();
                            string password = loginPasswordArray[1].Trim();
                            string rights = loginPasswordArray[2].Trim();
                            if (login == loginM && password == passwordM)       //сравниваем логим и пароль с данными из файла
                            {
                                accept = true;
                                messageToUser = "True," + rights;
                            }
                            else if (!accept)
                            {
                                messageToUser = "False," + rights;
                            }
                        }

                    }
                }
            }
            if (accept)     //если авториз успешна - отпр сообщ с результатом
            {
                Console.WriteLine(commandType + "|" + senderStr + "|" + "" + "|" + message);
                SendPrivateMessage(AllTypesOfCommands.Login, sender, senderStr, senderStr, messageToUser);
            }
            else            //иначе - отказ
            {
                Console.WriteLine(commandType + "|" + senderStr + "|" + "" + "|" + message);
                SendPrivateMessage(AllTypesOfCommands.Login, sender, senderStr, senderStr, "False, User");
            }

        }
        catch (Exception ex)
        {
            Console.WriteLine("Ошибка при чтении файла: " + ex.Message);
        }

    }
    private static void RegisterUser(AllTypesOfCommands commandType, TcpClient sender, string senderStr, string message)
    {
        Console.WriteLine(commandType + "|" + senderStr + "|" + "" + "|" + message);
        string[] parts = message.Split(',');
        string login = parts[0].Trim();
        string password = parts[1].Trim();
        string formatted = senderStr + ":" + login + "," + password;
        try
        {
            if (!LoginExists("AllUsers.txt", login) && !IpExists("AllUsers.txt", senderStr))
            {
                if (new FileInfo("AllUsers.txt").Length == 0)
                {
                    string userInfo = formatted + ",admin";
                    Console.WriteLine(commandType + "|" + senderStr + "|" + "" + "|" + message);
                    SendPrivateMessage(AllTypesOfCommands.Register, sender, senderStr, senderStr, "True,admin");
                    File.AppendAllText("AllUsers.txt", userInfo + Environment.NewLine);
                    return;
                }
                else {
                    string userInfo = formatted + ",user";
                    Console.WriteLine(commandType + "|" + senderStr + "|" + "" + "|" + message);
                    SendPrivateMessage(AllTypesOfCommands.Register, sender, senderStr, senderStr, "True,user");
                    File.AppendAllText("AllUsers.txt", userInfo + Environment.NewLine);
                    return;
                }
            }
            else
            {
                Console.WriteLine(commandType + "|" + senderStr + "|" + "" + "|" + message);
                SendPrivateMessage(AllTypesOfCommands.Register, sender, senderStr, senderStr, "False,user");
                Console.WriteLine("Логин/ip уже существует. Регистрация отклонена.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine("Ошибка при записи в файл:" + ex.Message);
            
        }
    }
    private static bool IpExists(string filePath, string login)
    {
        try
        {
            string[] lines = File.ReadAllLines(filePath);       //читает все строки из указанного файла и возвращает их в виде массива строк

            if (lines.Length > 0)
                return Array.Exists(lines, line => line.Contains(login));   //поиск нужной строки
            else
                return false;
        }
        catch (Exception ex)
        {
            Console.WriteLine("Ошибка при проверке логина: " + ex.Message);
            return false;
        }
    }
    private static bool LoginExists(string filePath, string senderStr)
    {
        try
        {
            string[] lines = File.ReadAllLines(filePath);
            if (lines.Length > 0)
            return Array.Exists(lines, line => line.Contains(senderStr));
            else
                return false;
        }
        catch (Exception ex)
        {
            Console.WriteLine("Ошибка при проверке логина: " + ex.Message);
            return false;
        }
    }
    private static void SendMessageAll(AllTypesOfCommands commandType, TcpClient sender, string senderStr, string receiverLogin, string message)
    {
        lock (lockObject)
        {
            var userLoginMap = new Dictionary<string, string>();
            string[] lines = File.ReadAllLines("AllUsers.txt");
            if (lines.Length > 0)
            {
                foreach (string line in lines)
                {
                    string[] parts = line.Split(':');
                    string[] loginPasswordParts = parts[1].Split(',');
                    if (loginPasswordParts.Length >= 3)
                    {
                        string ipAddress = parts[0];
                        string login = loginPasswordParts[0];
                        userLoginMap[login] = ipAddress;
                    }
                }
            }
            string senderLogin = userLoginMap.ContainsValue(senderStr) ? userLoginMap.First(x => x.Value == senderStr).Key : string.Empty;     //проверяется, существует ли IP-адрес отправителя в словаре. Если да, то извлекается соответствующий логин; если нет — устанавливается пустая строка
            foreach (var client in connectedClients.ToList())       //проходится по списку всех подключенных клиентов
            {
                if (client != sender)
                {
                    Console.WriteLine(commandType + "|" + senderStr + "|" + receiverLogin + "|" + message);
                    byte[] messageBytes = Encoding.UTF8.GetBytes(commandType + "|" + senderLogin + "|" + receiverLogin + "|" + message);
                    client.GetStream().Write(messageBytes, 0, messageBytes.Length);
                    client.GetStream().Flush();
                }
            }
        }
    }

    private static void SendPrivateMessage(AllTypesOfCommands commandType, TcpClient sender, string senderStr, string receiverLogin, string message)
    {
        lock (lockObject)
        {
            var userLoginMap = new Dictionary<string, string>();
            string[] lines = File.ReadAllLines("AllUsers.txt");
            if (lines.Length > 0)
            {
                foreach (string line in lines)
                {
                    string[] parts = line.Split(':');
                    string[] loginPasswordParts = parts[1].Split(',');
                    if (loginPasswordParts.Length >= 3)
                    {
                        string ipAddress = parts[0];
                        string login = loginPasswordParts[0];
                        userLoginMap[login] = ipAddress;
                    }
                }
            }
                //получение ip получателя и логина отправителя
                string receiverIpAddress = userLoginMap.ContainsKey(receiverLogin) ? userLoginMap[receiverLogin] : string.Empty;
                string senderLogin = userLoginMap.ContainsValue(senderStr) ? userLoginMap.First(x => x.Value == senderStr).Key : string.Empty;
                if (receiverIpAddress == "")
                    receiverIpAddress = receiverLogin;
            
            if (!string.IsNullOrEmpty(receiverIpAddress))   //если адрес получателя не пустой, поиск в списке подключенных
            {

                TcpClient targetClient = connectedClients.FirstOrDefault(c => ((IPEndPoint)c.Client.RemoteEndPoint).Address.ToString() == receiverIpAddress);

                if (targetClient != null)       //если клиент найден
                {
                    Console.WriteLine(commandType + "|" + senderStr + "|" + receiverIpAddress + "|" + message);
                    byte[] messageBytes = Encoding.UTF8.GetBytes(commandType + "|" + senderLogin + "|" + receiverLogin + "|" + message);
                    targetClient.GetStream().Write(messageBytes, 0, messageBytes.Length);
                    targetClient.GetStream().Flush();
                }
            }
            else
            {
                Console.WriteLine("Логин не найден. Невозможно отправить приватное сообщение.");
            }
        }
    }

    private static void UpdateAndSendUserList(TcpClient tcpClient)      //обновляет список пользователей и отправляет его конкретному клиенту в системе, использующей TCP-соединения
    {
        lock (lockObject)
        {

            var userLoginMap = new Dictionary<string, string>();
            string[] lines = File.ReadAllLines("AllUsers.txt");
            if (lines.Length > 0)
            {
                foreach (string line in lines)
                {
                    //string[] data = line.Split(':');
                    string[] parts = line.Split(':');
                    string[] loginPasswordParts = parts[1].Split(',');
                    if (loginPasswordParts.Length >= 3)
                    {
                        string ipAddress = parts[0];
                        string login = loginPasswordParts[0];
                        userLoginMap[ipAddress] = login;
                    }
                }
            }

            List<string> ListOfUsers = connectedClients        //формирование списка пользователей
                .Select(c => ((IPEndPoint)c.Client.RemoteEndPoint).Address.ToString())
                .Select(ip => userLoginMap.ContainsKey(ip) ? userLoginMap[ip] : ip)
                .ToList();
            //для каждого IP - адреса проверяется, есть ли он в словаре `userLoginMap`. Если есть — добавляется соответствующий логин, если нет — добавляется сам IP - адрес.


            //список пользователей преобразуется в строку, где логины разделены запятыми.
            string userListString = string.Join(",", ListOfUsers);
            SendUsersMessage(tcpClient, AllTypesOfCommands.UpdateUL, userListString, "");
        }
    }
    private static void SendUserLocalIPResponse(TcpClient tcpClient)    //отправляет пользователю его ip адрес
    {
        string localIP = "?";
        lock (lockObject)
        {
            IPAddress clientIP = ((IPEndPoint)tcpClient.Client.RemoteEndPoint).Address; //извлекается из свойства RemoteEndPoint объекта TcpClient

            if (clientIP.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)    //дрес клиента относится к семейству адресов InterNetwork (IPv4)
            {
                localIP = clientIP.ToString();
            }

            SendUsersMessage(tcpClient, AllTypesOfCommands.LocalUserIP, localIP, "");
        }
    }

    private static void SendUsersMessage(TcpClient tcpClient, AllTypesOfCommands commandType, string msg, string receiver)     //для отправки системных сообщений (отправить файлик и тд)
    {
        lock (lockObject)
        {
            NetworkStream clientStream = tcpClient.GetStream();
            Console.WriteLine(commandType + "|" + receiver + "|" + receiver + "|" + msg);
            byte[] messageBytes = Encoding.UTF8.GetBytes(commandType + "|" + receiver + "|" + receiver + "|" + msg);
            clientStream.Write(messageBytes, 0, messageBytes.Length);
            clientStream.Flush();
        }
    }

    private static Message BytesNotMessage(byte[] messageBytes, int bytesRead)      //расшифровка сообщ
    {
        string messageString = Encoding.UTF8.GetString(messageBytes, 0, bytesRead);
        string[] messageParts = messageString.Split('|');

        return new Message
        {
            AllTypesOfCommands = (AllTypesOfCommands)Enum.Parse(typeof(AllTypesOfCommands), messageParts[0]),
            Sender = messageParts[1],
            Receiver = messageParts[2],
            MSG = messageParts[3]
        };
    }
}